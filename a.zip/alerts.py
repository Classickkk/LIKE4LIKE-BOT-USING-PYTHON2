import pyautogui
import time

print("Executando código auxiliar")

# Lista de imagens para verificar
imagens = ['./base/ok.png', './base/nunca.png']

def verificar_e_clicar():
    while True:
        for imagem in imagens:
            try:
                # Verifica se a imagem está presente na tela
                pos = pyautogui.locateOnScreen(imagem, confidence=0.8)  # Ajuste 'confidence' se necessário
                if pos:
                    # Clica na imagem se encontrada
                    pyautogui.click(pyautogui.center(pos))
                    print(f"Imagem {imagem} encontrada e clique realizado.")
                    # break  # Sai do loop se quiser parar depois de clicar
                else:
                    print(f"Imagem {imagem} não encontrada, verificando novamente.")
            except pyautogui.ImageNotFoundException:
                # Ignora a exceção e continua verificando
                pass
        
        time.sleep(1)  # Tempo de espera entre verificações

# Executa a função
verificar_e_clicar()
