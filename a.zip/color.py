from colorama import init, Fore, Back, Style

# Prepara a Colorama para funcionar corretamente, especialmente em ambientes Windows.
init()

# Fore, Back, Style: São usados para aplicar cores e estilos ao texto e fundo, permitindo que você crie saídas de terminal mais claras e visualmente atraentes.
print(Fore.RED + 'Este texto é vermelho')
print(Back.GREEN + 'Este texto tem o fundo verde')
print(Style.BRIGHT + 'Este texto está em negrito')

# Style.RESET_ALL: Reseta todos os estilos e cores ao padrão, prevenindo que eles sejam aplicados a textos que você não deseja estilizar.
print(Style.RESET_ALL + 'Este é o texto padrão')