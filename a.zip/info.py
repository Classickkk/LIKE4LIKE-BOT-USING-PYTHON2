import pyautogui
import time
import pyperclip  # Biblioteca para manipular a área de transferência

# Caminho para a imagem do navegador
detect2_browser = './database/imgs/browser.png'

# Procura pela imagem na tela com confiança de 80%
detect2 = pyautogui.locateCenterOnScreen(detect2_browser, confidence=0.8)
if detect2:
    print("[DEBUG] Navegador encontrado!")
    pyautogui.click(detect2)
    #time.sleep(1)
    pyautogui.press('f6')
    #time.sleep(1)
    pyautogui.write('https://sacola.magazineluiza.com.br/#/cliente/editar')
    #time.sleep(1)
    pyautogui.press('enter')
    time.sleep(5)
    pyautogui.press('escape')  # Fecha pop-ups ou modal
    pyautogui.press('escape')
    pyautogui.press('escape')
    pyautogui.press('escape')
    pyautogui.press('escape')

    # Realiza 3 cliques na mesma posição (ajuste x, y conforme necessário)
    pyautogui.click(x=37, y=726)
    pyautogui.click(x=37, y=726)
    pyautogui.click(x=37, y=726)

    # Pressiona Ctrl+C para copiar o conteúdo selecionado
    pyautogui.hotkey('ctrl', 'c')
    time.sleep(1)  # Dá tempo para o sistema copiar o conteúdo

    # Obtém o valor da área de transferência
    cep_content = pyperclip.paste()
    print("[INFO] Conteúdo copiado da área de transferência:")
    print("CEP OBTIDO => ", cep_content)
    pyautogui.click(x=31, y=791)
    pyautogui.click(x=31, y=791)
    pyautogui.click(x=31, y=791)
    time.sleep(1) 
    pyautogui.hotkey('ctrl', 'c')
    time.sleep(1) 
    adress_info = pyperclip.paste()
    print("ENDEREÇO OBTIDO => ", adress_info)
    pyautogui.click(x=30, y=869)
    pyautogui.click(x=30, y=869)
    pyautogui.click(x=30, y=869)
    time.sleep(1)
    pyautogui.hotkey('ctrl', 'c')
    time.sleep(1) 
    number_info = pyperclip.paste()
    print("NUMERO OBTIDO => ", number_info)
    pyautogui.click(x=37, y=940)
    pyautogui.click(x=37, y=940)
    pyautogui.click(x=37, y=940)
    time.sleep(1)
    pyautogui.hotkey('ctrl', 'c')
    pyautogui.press('pagedown')
    time.sleep(1) 
    complemento_info = pyperclip.paste()
    print("COMPLEMENTO OBTIDO => ", complemento_info)
    pyautogui.click(x=37, y=180)
    pyautogui.click(x=37, y=180)
    pyautogui.click(x=37, y=180)
    time.sleep(1)
    pyautogui.hotkey('ctrl', 'c')
    time.sleep(1) 
    bairro_info = pyperclip.paste()
    print("BAIRRO OBTIDO => ", bairro_info)
    pyautogui.click(x=33, y=252)
    pyautogui.click(x=33, y=252)
    pyautogui.click(x=33, y=252)
    time.sleep(1) 
    pyautogui.hotkey('ctrl', 'c')
    time.sleep(1) 
    cidade_info = pyperclip.paste()
    print("CIDADE OBTIDA => ", cidade_info)
    pyautogui.click(x=26, y=327)
    pyautogui.click(x=26, y=327)
    pyautogui.click(x=26, y=327)
    time.sleep(1) 
    pyautogui.hotkey('ctrl', 'c')
    time.sleep(1) 
    estado_info = pyperclip.paste()
    print("ESTADO OBTIDO => ", estado_info)
    pyautogui.click(x=35, y=400)
    pyautogui.click(x=35, y=400)
    pyautogui.click(x=35, y=400)
    time.sleep(1) 
    pyautogui.hotkey('ctrl', 'c')
    time.sleep(1)     
    ref_info = pyperclip.paste()
    pyautogui.press('pageup')
    time.sleep(1)     
    print("PONTO DE REFÊRENCIA OBTIDO => ", ref_info)


else:
    print("[ERROR] Navegador não encontrado!")
    # Insira aqui as funções ou ações necessárias para tratar o erro.
