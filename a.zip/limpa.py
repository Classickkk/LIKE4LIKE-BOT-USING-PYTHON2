# Caminho do arquivo
input_file = './casasbahia.com.br.txt'
output_file = './casasbahia.com.br.txt'  # pode ser o mesmo arquivo, se preferir

# Função para lidar com diferentes codificações
def read_file_with_encoding(file_path):
    encodings = ['utf-8', 'iso-8859-1', 'ascii']
    for encoding in encodings:
        try:
            with open(file_path, 'r', encoding=encoding, errors='ignore') as file:
                return file.readlines()
        except Exception as e:
            print(f"Tentativa de leitura com {encoding} falhou: {e}")
    raise ValueError(f"Falha ao ler o arquivo {file_path} com as codificações tentadas.")

# Ler as linhas do arquivo com suporte a codificações
lines = read_file_with_encoding(input_file)

# Remover duplicatas usando um conjunto
unique_lines = list(set(lines))

# Opcionalmente, ordenar as linhas (remove o efeito de embaralhamento do set)
unique_lines.sort()

# Gravar as linhas únicas em um novo arquivo ou sobrescrever o original
with open(output_file, 'w', encoding='utf-8', errors='ignore') as file:
    file.writelines(unique_lines)

print(f"Linhas duplicadas removidas. Arquivo limpo gerado em: {output_file}")
