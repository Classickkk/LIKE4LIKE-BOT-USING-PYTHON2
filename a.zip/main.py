import subprocess
import os
import signal
import sys
from colorama import init, Fore, Back, Style
init(autoreset=True)
def main():
    # Inicializa o processo alerts.py em segundo plano
    alerts_process = subprocess.Popen(
        ["python", "alerts.py"],
        stdout=subprocess.DEVNULL,  # Oculta a saída do alerts.py
        stderr=subprocess.DEVNULL,  # Opcional: Oculta erros do alerts.py
        creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0
    )
    print("AUXILIAR INICIADO!")

    try:
        # Inicializa o processo bahia.py e redireciona sua saída para o console em tempo real
        with subprocess.Popen(
            ["python", "-u", "bahia.py"],  # O argumento "-u" desativa o buffering
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            universal_newlines=True,
            bufsize=1  # Garante que a saída seja processada linha a linha
        ) as bahia_process:
            print("CHECKER CASAS BAHIA INICIADO - PRESSIONE CRTL+C PARA ENCERRAR\n\nSAIDA DO CHECKER:\n\n")

            # Lê e imprime a saída de bahia.py em tempo real
            for line in bahia_process.stdout:
                print(line, end="")

    except KeyboardInterrupt:
        print("\nENCERRANDO CHECKER...")

    finally:
        # Finaliza ambos os processos ao encerrar o launcher
        if alerts_process.poll() is None:  # Verifica se alerts.py ainda está ativo
            try:
                if os.name == 'nt':
                    os.kill(alerts_process.pid, signal.CTRL_BREAK_EVENT)
                else:
                    alerts_process.terminate()
                alerts_process.wait()
                print("AUXILIAR ENCERRADO!")
            except Exception as e:
                print(f"ERRO AO ENCERRAR O AUXILIAR!: {e}")

        print("CHECKER ENCERRADO.")

if __name__ == "__main__":
    main()
