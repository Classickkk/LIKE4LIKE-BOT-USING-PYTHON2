import tkinter as tk
from tkinter import scrolledtext
from PIL import Image, ImageTk
import subprocess
import threading
import os
import queue

# Variáveis globais para os processos
alerts_process = None
magalu_process = None
output_queue = queue.Queue()  # Fila para armazenar saídas de subprocessos

# Função para iniciar um arquivo
def start_file(file_name):
    global alerts_process, magalu_process
    if file_name == "./alerts.py":
        if alerts_process is None:
            alerts_process = subprocess.Popen(["python", file_name])
            update_terminal(f"Iniciando {file_name}...")
            update_status_indicator(alert_status, True)
    elif file_name == "./magalu.py":
        if magalu_process is None:
            magalu_process = subprocess.Popen(
                ["python", file_name],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1  # Linha a linha
            )
            update_terminal(f"Iniciando {file_name}...")
            update_status_indicator(checker_status, True)
            threading.Thread(target=read_output, args=(magalu_process,), daemon=True).start()
            root.after(100, process_output_queue)  # Atualizar GUI periodicamente

# Função para parar um arquivo
def stop_file(file_name):
    global alerts_process, magalu_process
    if file_name == "./alerts.py" and alerts_process:
        alerts_process.terminate()
        alerts_process = None
        update_terminal(f"{file_name} foi parado.")
        update_status_indicator(alert_status, False)
    elif file_name == "./magalu.py" and magalu_process:
        magalu_process.terminate()
        magalu_process = None
        update_terminal(f"{file_name} foi parado.")
        update_status_indicator(checker_status, False)

# Função para atualizar os contadores de linhas
def update_counters():
    files = ["./live.txt", "./die.txt", "./recheck.txt", "./db.txt"]
    for i, file in enumerate(files):
        try:
            with open(file, "r") as f:
                line_count = len(f.readlines())
            counters[i].config(text=f"{os.path.basename(file)}: {line_count} linhas")
        except FileNotFoundError:
            counters[i].config(text=f"{os.path.basename(file)}: Arquivo não encontrado")

# Função para atualizar o terminal
def update_terminal(message):
    terminal.config(state="normal")
    terminal.insert("end", f"{message}\n")
    terminal.config(state="disabled")
    terminal.see("end")  # Rola automaticamente para o final

# Função para ler a saída do terminal em tempo real
def read_output(process):
    global output_queue
    while True:
        # Lê saída padrão
        output = process.stdout.readline()
        if output:
            output_queue.put(output.strip())
        
        # Lê erros padrão
        error = process.stderr.readline()
        if error:
            output_queue.put(f"ERRO: {error.strip()}")
        
        # Sai do loop quando o processo termina
        if process.poll() is not None:
            break

    # Garante que qualquer saída restante seja lida
    process.stdout.close()
    process.stderr.close()

def process_output_queue():
    while not output_queue.empty():
        line = output_queue.get_nowait()
        update_terminal(line)
    
    # Continua verificando se o processo ainda está rodando
    if magalu_process and magalu_process.poll() is None:
        root.after(100, process_output_queue)


# Função para atualizar os indicadores de status
def update_status_indicator(label, running):
    label.config(text="Executando" if running else "Parado", fg="green" if running else "red")

# Função para aplicar efeito de hover nos botões
def add_hover_effect(button, color_on_hover, color_on_leave):
    def on_enter(e):
        button["bg"] = color_on_hover
    def on_leave(e):
        button["bg"] = color_on_leave
    button.bind("<Enter>", on_enter)
    button.bind("<Leave>", on_leave)

# Configuração da janela principal
root = tk.Tk()
root.title("CHECKER MAGALU @ClassicX-O-BRABO")
root.geometry("900x600")
root.configure(bg="black")

# Adicionar a logo no topo
logo_image = Image.open('./icon.ico')
logo_image = logo_image.resize((128, 128), Image.LANCZOS)
logo = ImageTk.PhotoImage(logo_image)
logo_label = tk.Label(root, image=logo, bg="black")
logo_label.pack(pady=10)

# Frame para botões horizontais
button_frame = tk.Frame(root, bg="black")
button_frame.pack(pady=10)

# Botões horizontais
btn_start_alerts = tk.Button(button_frame, text="INICIAR BYPASS ALERTAS", bg="black", fg="white",
                             font=("Arial", 10, "bold"), relief="solid", bd=2)
btn_stop_alerts = tk.Button(button_frame, text="PARAR BYPASS ALERTAS", bg="black", fg="white",
                            font=("Arial", 10, "bold"), relief="solid", bd=2)
btn_reload = tk.Button(button_frame, text="RECARREGAR DATABASE", bg="black", fg="white",
                       font=("Arial", 10, "bold"), relief="solid", bd=2, command=update_counters)
btn_start_checker = tk.Button(button_frame, text="INICIAR CHECKER", bg="black", fg="white",
                              font=("Arial", 10, "bold"), relief="solid", bd=2)
btn_stop_checker = tk.Button(button_frame, text="PARAR CHECKER", bg="black", fg="white",
                             font=("Arial", 10, "bold"), relief="solid", bd=2)

# Adicionar comandos aos botões
btn_start_alerts.config(command=lambda: start_file("./alerts.py"))
btn_stop_alerts.config(command=lambda: stop_file("./alerts.py"))
btn_start_checker.config(command=lambda: start_file("./magalu.py"))
btn_stop_checker.config(command=lambda: stop_file("./magalu.py"))

# Adicionar efeito hover nos botões
buttons = [btn_start_alerts, btn_stop_alerts, btn_reload, btn_start_checker, btn_stop_checker]
for button in buttons:
    add_hover_effect(button, "gray", "black")

btn_start_alerts.pack(side="left", padx=5, pady=5)
btn_stop_alerts.pack(side="left", padx=5, pady=5)
btn_reload.pack(side="left", padx=5, pady=5)
btn_start_checker.pack(side="left", padx=5, pady=5)
btn_stop_checker.pack(side="left", padx=5, pady=5)

# Frame para os contadores de linhas
counter_frame = tk.Frame(root, bg="black")
counter_frame.pack(side="left", padx=20, pady=20)

files = ["./live.txt", "./die.txt", "./recheck.txt", "./db.txt"]
counters = []
for file in files:
    counter = tk.Label(counter_frame, text=f"{os.path.basename(file)}: 0 linhas", fg="white", bg="black", font=("Arial", 10, "bold"))
    counter.pack(anchor="w", pady=2)
    counters.append(counter)

# Indicadores de status
status_frame = tk.Frame(root, bg="black")
status_frame.pack(side="right", padx=20, pady=20)

alert_status = tk.Label(status_frame, text="Parado", fg="red", bg="black", font=("Arial", 10, "bold"))
checker_status = tk.Label(status_frame, text="Parado", fg="red", bg="black", font=("Arial", 10, "bold"))

tk.Label(status_frame, text="BYPASS DE ALERTAS", fg="white", bg="black", font=("Arial", 10, "bold")).pack(anchor="w")
alert_status.pack(anchor="w", pady=5)
tk.Label(status_frame, text="ESTADO DO CHECKER:", fg="white", bg="black", font=("Arial", 10, "bold")).pack(anchor="w")
checker_status.pack(anchor="w", pady=5)

# Área do terminal
terminal = scrolledtext.ScrolledText(root, height=10, bg="black", fg="white", font=("Consolas", 10), state="disabled", wrap="none")
terminal.pack(fill="both", expand=True, pady=10)
update_terminal("\n                       Code by @ClassicX-O-BRABO                       ")

# Loop principal da interface
root.mainloop()
