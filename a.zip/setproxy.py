import winreg
import random

def configurar_proxy(proxy_server):
    try:
        chave_registro = r"SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings"

        chave = winreg.OpenKey(winreg.HKEY_CURRENT_USER, chave_registro, 0, winreg.KEY_SET_VALUE)
        
        # Define ProxyEnable como 1
        winreg.SetValueEx(chave, "ProxyEnable", 0, winreg.REG_DWORD, 1)
        
        # Define o ProxyServer com o valor escolhido
        winreg.SetValueEx(chave, "ProxyServer", 0, winreg.REG_SZ, proxy_server)
        
        # Fecha a chave do Registro
        winreg.CloseKey(chave)
        
        print(f"Proxy configurado com sucesso: {proxy_server}")
    except Exception as e:
        print(f"Erro ao configurar o proxy: {e}")

def selecionar_proxy(arquivo_proxy):
    try:
        # Lê todas as linhas do arquivo proxy.txt
        with open(arquivo_proxy, 'r') as arquivo:
            linhas = arquivo.readlines()
        
        # Remove quebras de linha e linhas vazias
        proxies = [linha.strip() for linha in linhas if linha.strip()]
        
        # Escolhe uma linha aleatória
        if proxies:
            return random.choice(proxies)
        else:
            print("Nenhum proxy encontrado no arquivo.")
            return None
    except FileNotFoundError:
        print(f"Arquivo {arquivo_proxy} não encontrado.")
        return None
    except Exception as e:
        print(f"Erro ao ler o arquivo de proxy: {e}")
        return None

# Caminho do arquivo de proxy
arquivo_proxy = "proxy.txt"

# Seleciona um proxy aleatório
proxy_selecionado = selecionar_proxy(arquivo_proxy)

if proxy_selecionado:
    # Configura o proxy com o valor selecionado
    configurar_proxy(proxy_selecionado)
