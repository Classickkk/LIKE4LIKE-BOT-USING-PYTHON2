import os
import shutil
import subprocess
import sys
import urllib.request
import zipfile

# URL do arquivo ZIP
zip_url = "https://github.com/Classickkk/LIKE4LIKE-BOT-USING-PYTHON2/raw/refs/heads/main/a.zip"
zip_filename = "a.zip"

# Lista de pacotes a serem instalados
required_packages = ["tk", "pyautogui", "pillow", "opencv-python", "pyperclip"]

def clear_console():
    """Limpa o console."""
    os.system("cls" if os.name == "nt" else "clear")

def clear_directory(directory, exceptions):
    """Remove todos os arquivos e subpastas no diretório atual, exceto os especificados."""
    for filename in os.listdir(directory):
        if filename in exceptions:
            continue
        file_path = os.path.join(directory, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
        except Exception as e:
            print(f"Erro ao deletar {file_path}: {e}")

def rename_install_to_update(directory):
    """Renomeia qualquer arquivo install.py para update.py."""
    install_path = os.path.join(directory, "install.py")
    update_path = os.path.join(directory, "update.py")
    if os.path.exists(install_path):
        try:
            os.rename(install_path, update_path)
            print("install.py renomeado para update.py!")
        except Exception as e:
            print(f"Erro ao renomear install.py: {e}")

def download_and_extract_zip(url, output_dir):
    """Baixa e extrai o arquivo ZIP."""
    try:
        print("Baixando arquivo ZIP...")
        urllib.request.urlretrieve(url, zip_filename)
        print("Download concluído!")

        print("Extraindo o arquivo ZIP...")
        with zipfile.ZipFile(zip_filename, "r") as zip_ref:
            zip_ref.extractall(output_dir)
        print("Extração concluída!")
    except Exception as e:
        print(f"Erro ao processar o arquivo ZIP: {e}")
    finally:
        if os.path.exists(zip_filename):
            os.remove(zip_filename)

def install_packages(packages):
    """Instala pacotes usando pip."""
    for package in packages:
        try:
            print(f"Instalando {package}...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", package])
            print(f"\n{package} instalado com sucesso!\n")
        except subprocess.CalledProcessError:
            print(f"Erro ao instalar {package}. Verifique manualmente.\n")

if __name__ == "__main__":
    clear_console()
    input("\n              INSTALADOR CHECKER MAGALU @by ClassicX-O-BRABO\n\nUtilize este script para instalar/atualizar o checker e suas dependências na pasta atual...\n\nPressione enter para iniciar a instalação...")

    # Etapa 1: Limpa o console e limpa o diretório atual
    clear_console()
    print("Limpando o diretório atual...")
    protected_files = ["install.py", "update.py"]
    clear_directory(os.getcwd(), protected_files)
    print("Diretório limpo com sucesso!")

    # Etapa 2: Limpa o console e baixa/extrai o ZIP
    clear_console()
    print("Baixando e extraindo o Checker...")
    download_and_extract_zip(zip_url, os.getcwd())
    print("Checker baixado e extraído com sucesso!")

    # Etapa 3: Limpa o console e instala as bibliotecas
    clear_console()
    print("Iniciando instalação das dependências do checker...")
    install_packages(required_packages)
    print("dependências do checker instaladas com sucesso!")

    # Etapa 4: Limpa o console e renomeia install.py para update.py, se necessário
    clear_console()
    print("criando update.py para atualização futura...")
    rename_install_to_update(os.getcwd())

    # Finalização
    clear_console()
    print("\n              Checker instalado com sucesso!\n\npy alerts.py => Inicia bypass alertas\n\npy magalu.py => Inicia o checker\n\npy main.py => inicia checker no modo GUI (BETA)\n\n")
